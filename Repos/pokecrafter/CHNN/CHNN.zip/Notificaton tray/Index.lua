title = System.startKeyboard("What the hell is this, Ruben!?!?!?")

text = System.startKeyboard("Testing 3ds notifications system... Success!")

while true do 
	pad = Controls.read()
	if (Controls.check(pad,KEY_A)) then
		System.addNews(title,text)
end
end
