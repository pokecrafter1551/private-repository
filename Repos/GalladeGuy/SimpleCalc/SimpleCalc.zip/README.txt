TO INSTALL:

Put the "Simple-Calc" folder in the "3ds" folder on the root of you SD Card.

CREDITS:
GalladeGuy - Creator
Hobbledehoy899