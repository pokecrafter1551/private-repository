Sunshell is a multifunction shell for Nintendo 3DS and it runs under a modified version of lpp-3ds.
Current release is an Alpha so it can be extremely bugged, please report on GBAtemp release topic any issue you encounter.

Sunshell provides a modules system: any developer can work to port its homebrew to Sunshell as a module and Sunshell modules could run also in background. Sunshell sourcecode is highly commented and idented to simplify devs works for conversion of their homebrews to Sunshell modules.

There are a lot of pre-installed modules:
- Videos: A video player which supports JPGV and BMPV videos
- Musics: A music player which supports WAV, OGG and AIFF musics
- Photos: A photo viewer which supports JPG, BMP and PNG images
- Filebrowser: A powerful filebrowser with lot of features
- Console Info: An info viewer to know some info about your system (Model, Kernel Version, System Version, Mac Address, etc...)
- Mail: A mail sender application
- Calc: A scientific/developers calculator like Windows ones
- CIA Manager: A CIA manager
- Applications: A 3DSX, imported CIA, Game Cartridge launcher
- Clock: A Cronometer, Countdown and Alarm clock utility
- FTP Server: An FTP Server utility
- Extdata Manager: An extdata dumper/restorer
- Themes Manager: Customize Sunshell with your themes

Installation:
- Copy "config.sun" file from "Common Files" folder to the root of your SD card
- Open "config.sun" file with a Text Editor and set your preferred main_dir
- Copy folders from "Common Files" to your main_dir
- Copy "sun_index.lua" file from "Common Files" to the same directory of your build executable (SD root for 3DS/CIA)


Video files must be put in VIDEO folder.
Music files must be put in MUSIC folder (It support subfolders as Music categorization system).
Photos must be put in DCIM folder (It support also subfolders).


General Controls (Working on all Modules):
START = Exit Sunshell
L = Take Screenshot

Pre-installed homebrews:
Thanks to lpp-3ds usage for Sunshell, you can use LUA homebrews as pre-installed homebrews reducing the filesize of these homebrews by deleting the 3DSX/CIA/3DS executable. To do this, just create a folder in apps folder named as the Homebrew name and place all the homebrew contents inside it. At the end, create a data.lua file with these information inside:
app_desc = "Description of the homebrew"
app_author = "Homebrew author"
 
Changelogs:
------------------
--   v.0.3.8    --
------------------
- Solved flickering issues for 3DS/CIA builds and NH2 build.
- Added Username and Birthday info in Console Info module.
- Now both screens can be powered off during audio reproduction in Music module to save battery. (Ninjhax 1/CFs)
- Now bottom screen can be powered off during videos reproduction in Video module to save battery. (Ninjhax 1/CFs)
- Now an error occur if you try to open Music module with MUSIC folder empty.
- Now Console Info correctly shows Firmware and Kernel builds.
- Now Ninjhax 2 users cannot access to incompatible modules (like FTP Server).
- Now Console Info correctly identify Ninjhax 2 build.
- Removed old pre-build CHMM homebrew.
- Solved some audio disturb effects during JPGV videos with Vorbis audiocodec and OGG audio files playback.
- Huge speedup for the entire homebrew.
- Solved a bug in Main Menu which could cause icon selector to point to a null icon.
- Now Wifi status is correctly recognized (Low connection = 1 bar, Medium connection =  2 bars, Good connection = 3 bars)
- Added possibility to transfer files between SD cards with Filebrowser (Only Ninjhax users). [Filesize must be 20 MB or lower]
- Solved random freezing issues with non Stereo Vorbis video files.
- Solved issue which cause titles parsing losing if you switch between modes in CIA Manager module.
- Solved issue which cause titles parsing losing if an uninstallation is triggered in CIA Manager module.
- Bugfix for screenshots, now bottom screen space borders (left/right) are always black.
- Bugfix for Free Space detection in Console Info module. Now is correctly recognized.
- Bugfix for IP Address detection in Console Info module. Now is correctly recognized.
- Added 3D support for JPGV videos playback.

------------------
--     V.0.3    --
------------------
- Added TTF Viewer to available softwares in Filebrowser Module.
- Added support for OGG metadatas extraction (Title and Author).
- Updated titles database for parsing feature.
- Now statusbar on Video module updates its status in realtime and not by percentage changes.
- Solved a bug in Extdata Module which causes crash if you open a file, exit module and re-enter it.
- Solved random "error reading file" crashes bug.
- Added icon on topbar when WiFi is off.
- Added background icon system support to Clock module.
- Solved Calc module issue which prevents you to append decimals to zero.
- Solved Calc module issue which prevents you to append zeros as decimals.
- Solved Calc module issue which causes crash if you try to delete a one-digit number.
- Solved Calc module issue which causes crash if you click equal button before doing any operation.
- Added Theme Manager module to apply Sunshell themes.
- Solved screen flickering issue with errors and warnings.
- Added CIA importing support to Filebrowser for 3DSX build.
- Added imported CIA support to Applications for 3DSX build.
- Added CIA Manager access to 3DSX build.
- Added sound support to 3DSX build for N3DS users.
- Added "Song" Cycle Mode in Music module to loop a single song.
- Solved noise and overlap issues with big duration OGG files.
- Solved random crashes issue with music playback.
- Solved wrong audio end (with overlap) for OGG files.
- Added Vorbis audiocodec support for JPGV videos in Filebrowser and Videos.
- Solved stuttering issues if an OGG file is playing.
- Solved random flickering screen issue with font usage.
- Made controls triggering more reactive in Music module.
- Now font printing will be used also in Extdata Manager, Filebrowser, Calc, Mail, FTP Server and Photo modules.
- Changed default font with a more complete ones.
- Now currently played song will be printed in blue in file list in Music module.
- Solved wrong "&" char blending in Applications module.

------------------
--  v.0.2 BETA  --
------------------

- Solved bad RAM managing by Applications module.
- Solved bad RAM managing by Video module.
- Little framerate speedup for JPGV videos.
- Solved stuttering issue with Music module.
- Solved stuttering issue with JPGV video files.
- Enabled CIA files support on Filebrowser for .3DS build.
- Improved CIA detection for .3DS build for Applications.
- Enabled CIA Manager access for .3DS build.
- Enabled sound support for .3DS build. (Clock, Videos, Musics, Filebrowser)
- Added possibility to hide bottom screen during video playback (could improve playback framerate).
- Added background working modules icon showing on Sunshell topbar.
- Improved customization level and shell graphics by adding TTF fonts usage for texts.
- Solved a bug with 3DSX Launcher of Filebrowser module.
- Added Game titles parsing in CIA Manager module.
- Chronometer now is correctly named.
- Added headset triggering for Music module autostart/autopause.
- Solved an incompatibility bug between Musics and Photos modules.
- Solved an incompatibility bug between Videos and Photos modules.
- Solved an incompatibility bug between Musics and Videos modules.
- Added OGG musics support to Musics Module and Filebrowser Module.
- Updated Game Titles List.
- Added digital pad + A buttons support on Main Menu.
- Solved a little bug between Filebrowser module and Wifi status icon color.
- Added Extdata Manager module.

------------------
-- v.0.1 ALPHA2 --
------------------

- Added CHMM as pre-installed homebrew.
- Added pre-installed homebrews system to Applications for LUA homebrews.
- Now screenshots are taken in JPG format (saving space on SD).
- Now screenshots can be taken also in Filebrowser module.
- Added controls information in Filebrowser module.
- Changed controls for Filebrowser module
- Added Game titles parsing for imported CIAs in Applications module.
- Added Wifi status icon to Sunshell topbar.
- Solved a bug with Wifi status detection after disabling it.
- Added controls information in Mail module.
- Solved little bug with controls triggering in Mail module.
- Blocked access to Mail service for CIA/3DS builds cause incompatibility.
- Made boot.3dsx patch compatible with CIA/3DS builds.
- Changed Banner for 3DS/CIA build (Thanks to Apache_Thunder).
- Now you can take multiple screenshots without overwriting the old ones.
- Now screenshots are saved in DCIM folder.
- Solved a bug with calendar days printing.
- Solved error if you try to use Music Module with an empty MUSIC folder.
- Solved error if you try to use Video Module with an empty VIDEO folder.
- Solved error if you try to take a screenshot with a non-existing DCIM/101NIN03 folder.